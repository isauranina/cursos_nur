﻿namespace Nur.Gateway.Web.Dto
{
    public class InventarioItem
    {
        public int Stock { get; set; }
    }
}
